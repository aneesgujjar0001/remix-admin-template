# Backend smoke test

After starting the API:

```bash
curl http://localhost:8000/health
```

Register:

```bash
curl -X POST http://localhost:8000/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"name":"Anees","email":"anees@example.com","password":"changeMe123"}'
```

Use the returned `access_token`:

```bash
curl http://localhost:8000/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Create a conversation:

```bash
curl -X POST http://localhost:8000/conversations \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"title":"Mathematics"}'
```

Send a message:

```bash
curl -X POST http://localhost:8000/conversations/1/messages \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"message":"Explain derivatives like I am new to calculus."}'
```
