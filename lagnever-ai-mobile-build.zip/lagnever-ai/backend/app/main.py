from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.orm import Session

from .ai import tutor_reply
from .auth import create_access_token, get_current_user, hash_password, verify_password
from .config import settings
from .db import Base, engine, get_db
from .models import Conversation, Message, User
from .schemas import (
    ChatRequest,
    ChatResponse,
    ConversationCreate,
    ConversationOut,
    LoginRequest,
    MessageOut,
    TokenOut,
    UserCreate,
    UserOut,
)

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Lagnever AI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_owned_conversation(db: Session, user_id: int, conversation_id: int) -> Conversation:
    convo = db.scalar(
        select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.user_id == user_id,
        )
    )
    if not convo:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return convo


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/auth/register", response_model=TokenOut)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    email = payload.email.lower().strip()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(name=payload.name.strip(), email=email, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return TokenOut(access_token=create_access_token(user.id), user=user)


@app.post("/auth/login", response_model=TokenOut)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    email = payload.email.lower().strip()
    user = db.scalar(select(User).where(User.email == email))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return TokenOut(access_token=create_access_token(user.id), user=user)


@app.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user


@app.get("/conversations", response_model=list[ConversationOut])
def list_conversations(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return list(
        db.scalars(
            select(Conversation)
            .where(Conversation.user_id == user.id)
            .order_by(Conversation.created_at.desc())
        )
    )


@app.post("/conversations", response_model=ConversationOut)
def create_conversation(
    payload: ConversationCreate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    convo = Conversation(user_id=user.id, title=payload.title.strip() or "New conversation")
    db.add(convo)
    db.commit()
    db.refresh(convo)
    return convo


@app.get("/conversations/{conversation_id}/messages", response_model=list[MessageOut])
def list_messages(
    conversation_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    convo = get_owned_conversation(db, user.id, conversation_id)
    return list(db.scalars(select(Message).where(Message.conversation_id == convo.id).order_by(Message.created_at)))


@app.post("/conversations/{conversation_id}/messages", response_model=ChatResponse)
def send_message(
    conversation_id: int,
    payload: ChatRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    convo = get_owned_conversation(db, user.id, conversation_id)
    history_rows = list(
        db.scalars(
            select(Message)
            .where(Message.conversation_id == convo.id)
            .order_by(Message.created_at)
            .limit(40)
        )
    )
    history = [{"role": row.role, "content": row.content} for row in history_rows]
    history.append({"role": "user", "content": payload.message})

    user_message = Message(conversation_id=convo.id, role="user", content=payload.message.strip())
    db.add(user_message)
    db.flush()

    try:
        answer = tutor_reply(history)
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=502, detail=f"AI service error: {exc}")

    assistant_message = Message(conversation_id=convo.id, role="assistant", content=answer)
    db.add(assistant_message)
    db.commit()
    db.refresh(user_message)
    db.refresh(assistant_message)

    return ChatResponse(user_message=user_message, assistant_message=assistant_message)
