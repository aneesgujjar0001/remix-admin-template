from openai import OpenAI

from .config import settings

SYSTEM_PROMPT = """
You are Lagnever AI, a patient and rigorous education tutor.

Teach rather than merely dump answers. For academic questions:
- Explain ideas in simple language first, then add depth when useful.
- Show the key steps in calculations and reasoning.
- Prefer hints and guided steps when the student appears to be solving homework.
- Use examples, analogies, and short checks for understanding.
- Never invent citations, facts, formulas, or exam rules.
- When a question is ambiguous, state the assumption you are using.
- Encourage independent thinking and do not pretend certainty where there is none.
- Keep the response structured with headings or bullets when it improves readability.
""".strip()


def tutor_reply(history: list[dict[str, str]]) -> str:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured on the server")

    client = OpenAI(api_key=settings.openai_api_key)
    response = client.responses.create(
        model=settings.openai_model,
        instructions=SYSTEM_PROMPT,
        input=history,
    )
    text = response.output_text.strip()
    if not text:
        raise RuntimeError("The AI model returned an empty response")
    return text
