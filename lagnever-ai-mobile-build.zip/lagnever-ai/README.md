# Lagnever AI

A production-oriented starter for an AI education app:

- Android app: Kotlin + Jetpack Compose + Material 3
- Backend: FastAPI + SQLAlchemy + PostgreSQL
- Authentication: JWT access tokens + bcrypt password hashing
- AI tutor: OpenAI Responses API, model configurable with `OPENAI_MODEL` (default: `gpt-6-astra`)
- Chat history persisted per user

## Architecture

```text
Android (Compose)
      |
      | HTTPS/JSON
      v
FastAPI REST API
  |            \
  |             +--> OpenAI Responses API
  v
PostgreSQL
```

## 1. Run the backend

### Option A: Docker Compose

```bash
docker compose up --build
```

The API will be available at `http://localhost:8000`.

### Option B: Local Python

```bash
cd backend
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

For PostgreSQL, either use your own database or run only the DB service:

```bash
docker compose up -d db
```

## 2. Configure the AI key

Copy `.env.example` to `.env` and set:

```env
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-6-astra
```

You can change `OPENAI_MODEL` to another API model available to your account.

**Never ship the OpenAI API key inside the Android app.** The mobile app talks only to your backend.

## 3. Open the Android project

Open the `android/` directory in Android Studio.

For the Android emulator, the default API URL is:

```text
http://10.0.2.2:8000/
```

For a physical phone, set `API_BASE_URL` in `android/app/build.gradle.kts` to your computer's LAN address, for example `http://192.168.1.10:8000/`.

For production, use HTTPS.

## 4. Test flow

1. Register a new user.
2. Sign in.
3. Ask the AI tutor a question.
4. The conversation is saved in PostgreSQL.
5. Close/reopen the app and the session remains until you log out.

## API endpoints

- `POST /auth/register`
- `POST /auth/login`
- `GET /me`
- `GET /conversations`
- `POST /conversations`
- `GET /conversations/{conversation_id}/messages`
- `POST /conversations/{conversation_id}/messages`
- `GET /health`

Interactive API docs: `http://localhost:8000/docs`

## Production hardening

This starter intentionally keeps the implementation understandable. Before production, add:

- HTTPS and a real domain
- refresh-token rotation / revocation
- email verification + password reset
- rate limiting and abuse detection
- app attestation / device protections as appropriate
- stronger audit logging and observability
- background jobs for analytics and notifications
- content moderation / age-appropriate education policies
- secure secret management instead of `.env` files on servers
- database migrations with Alembic
- automated tests and CI/CD
