package com.lagnever.ai

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface LagneverApi {
    @POST("auth/register") suspend fun register(@Body request: AuthRequest): AuthResponse
    @POST("auth/login") suspend fun login(@Body request: AuthRequest): AuthResponse
    @GET("me") suspend fun me(): User
    @GET("conversations") suspend fun conversations(): List<Conversation>
    @POST("conversations") suspend fun createConversation(@Body request: CreateConversationRequest): Conversation
    @GET("conversations/{id}/messages") suspend fun messages(@Path("id") id: Int): List<Message>
    @POST("conversations/{id}/messages") suspend fun chat(@Path("id") id: Int, @Body request: ChatRequest): ChatResponse
}

object ApiProvider {
    private val tokenInterceptor = Interceptor { chain ->
        val original = chain.request()
        val token = SessionStore.token
        val request: Request = if (token.isNullOrBlank()) original else original.newBuilder()
            .addHeader("Authorization", "Bearer $token")
            .build()
        chain.proceed(request)
    }

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    val api: LagneverApi by lazy {
        val client = OkHttpClient.Builder()
            .addInterceptor(tokenInterceptor)
            .addInterceptor(logging)
            .build()
        Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LagneverApi::class.java)
    }
}
