package com.lagnever.ai

import android.content.Context

object SessionStore {
    private const val PREFS = "lagnever_session"
    private const val KEY_TOKEN = "token"

    private lateinit var prefs: android.content.SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    var token: String?
        get() = if (::prefs.isInitialized) prefs.getString(KEY_TOKEN, null) else null
        set(value) {
            if (!::prefs.isInitialized) return
            prefs.edit().putString(KEY_TOKEN, value).apply()
        }

    @Volatile var user: User? = null

    fun clear() {
        user = null
        if (::prefs.isInitialized) prefs.edit().remove(KEY_TOKEN).apply()
    }
}
