package com.lagnever.ai

import com.google.gson.annotations.SerializedName


data class AuthRequest(val name: String? = null, val email: String, val password: String)
data class User(
    val id: Int,
    val name: String,
    val email: String,
    @SerializedName("created_at") val createdAt: String
)
data class AuthResponse(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("token_type") val tokenType: String,
    val user: User
)
data class Conversation(
    val id: Int,
    val title: String,
    @SerializedName("created_at") val createdAt: String
)
data class CreateConversationRequest(val title: String = "New conversation")
data class Message(
    val id: Int,
    val role: String,
    val content: String,
    @SerializedName("created_at") val createdAt: String
)
data class ChatRequest(val message: String)
data class ChatResponse(
    @SerializedName("user_message") val userMessage: Message,
    @SerializedName("assistant_message") val assistantMessage: Message
)
