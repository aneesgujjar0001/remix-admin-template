package com.lagnever.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SessionStore.init(applicationContext)
        setContent { LagneverApp() }
    }
}

private val Brand = Color(0xFF5B48E8)
private val Background = Color(0xFFF7F8FC)

@Composable
fun LagneverApp() {
    var loggedIn by remember { mutableStateOf(SessionStore.token != null) }
    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        if (!loggedIn) {
            AuthScreen(onLoggedIn = { loggedIn = true })
        } else {
            HomeScreen(onLogout = {
                SessionStore.clear()
                loggedIn = false
            })
        }
    }
}

@Composable
fun AuthScreen(onLoggedIn: () -> Unit) {
    var isRegister by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    fun submit() {
        error = ""
        loading = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = if (isRegister) {
                    ApiProvider.api.register(AuthRequest(name = name, email = email, password = password))
                } else {
                    ApiProvider.api.login(AuthRequest(email = email, password = password))
                }
                SessionStore.token = response.accessToken
                SessionStore.user = response.user
                withContext(Dispatchers.Main) { onLoggedIn() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { error = e.message ?: "Something went wrong" }
            } finally {
                withContext(Dispatchers.Main) { loading = false }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(60.dp), tint = Brand)
        Spacer(Modifier.height(14.dp))
        Text("Lagnever AI", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Your personal AI study partner", color = Color.Gray)
        Spacer(Modifier.height(28.dp))
        if (isRegister) {
            OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Name") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(email, { email = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = ::submit, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
            if (loading) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            else Text(if (isRegister) "Create account" else "Sign in")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { isRegister = !isRegister }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isRegister) "I already have an account" else "Create a new account")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onLogout: () -> Unit) {
    var conversations by remember { mutableStateOf<List<Conversation>>(emptyList()) }
    var currentConversation by remember { mutableStateOf<Conversation?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    fun load() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val list = ApiProvider.api.conversations()
                withContext(Dispatchers.Main) { conversations = list; loading = false }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { error = e.message ?: "Could not load conversations"; loading = false }
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) { load() }

    if (currentConversation != null) {
        ChatScreen(
            conversation = currentConversation!!,
            onBack = { currentConversation = null; load() }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lagnever AI", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Background),
                actions = {
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, contentDescription = "Log out") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(22.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Brand)
                            Spacer(Modifier.size(10.dp))
                            Text("Study smarter", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Ask anything, understand the why, and build confidence one concept at a time.", color = Color.Gray)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = {
                            CoroutineScope(Dispatchers.IO).launch {
                                val convo = ApiProvider.api.createConversation(CreateConversationRequest())
                                withContext(Dispatchers.Main) { currentConversation = convo }
                            }
                        }) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.size(8.dp))
                            Text("Start new lesson")
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(6.dp)); Text("Recent lessons", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            if (loading) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
            items(conversations) { convo ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { currentConversation = convo },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(14.dp), color = Brand.copy(alpha = 0.10f)) {
                            Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, modifier = Modifier.padding(12.dp), tint = Brand)
                        }
                        Spacer(Modifier.size(14.dp))
                        Column { Text(convo.title, fontWeight = FontWeight.SemiBold); Text("Open lesson", color = Color.Gray, fontSize = 13.sp) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(conversation: Conversation, onBack: () -> Unit) {
    val messages = remember { mutableStateListOf<Message>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    fun load() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val rows = ApiProvider.api.messages(conversation.id)
                withContext(Dispatchers.Main) { messages.clear(); messages.addAll(rows); loading = false }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { error = e.message ?: "Could not load chat"; loading = false }
            }
        }
    }

    fun send() {
        val text = input.trim()
        if (text.isBlank() || sending) return
        input = ""
        sending = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val result = ApiProvider.api.chat(conversation.id, ChatRequest(text))
                withContext(Dispatchers.Main) { messages.add(result.userMessage); messages.add(result.assistantMessage) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { error = e.message ?: "AI request failed" }
            } finally {
                withContext(Dispatchers.Main) { sending = false }
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(conversation.id) { load() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(conversation.title, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }
            )
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().background(Color.White).navigationBarsPadding().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask Lagnever AI…") },
                    maxLines = 4
                )
                Spacer(Modifier.size(8.dp))
                IconButton(onClick = ::send, enabled = !sending && input.isNotBlank()) {
                    if (sending) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.Send, contentDescription = "Send", tint = Brand)
                }
            }
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Tutor mode", color = Brand, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Lagnever will explain concepts, show steps, and help you learn instead of simply giving answers.", color = Color.Gray)
                }
                itemsIndexed(messages) { _, message ->
                    val mine = message.role == "user"
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = if (mine) Brand else Color.White,
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth(if (mine) 0.84f else 0.92f)
                        ) {
                            Text(
                                message.content,
                                modifier = Modifier.padding(16.dp),
                                color = if (mine) Color.White else Color(0xFF202124)
                            )
                        }
                    }
                }
                if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}
