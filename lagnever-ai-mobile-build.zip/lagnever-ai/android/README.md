# Lagnever AI Android App

Open this folder in Android Studio.

Default emulator API endpoint:
`http://10.0.2.2:8000/`

Physical device: edit `API_BASE_URL` in `app/build.gradle.kts` to your development computer's LAN IP.

The OpenAI API key never belongs in this app. Authentication tokens are stored in Android SharedPreferences for this MVP; for a hardened production app, use encrypted storage / Android Keystore-backed protection.
